
struct ItemModel: Codable {
    let id: Int
    let title: String
    var isSelected: Bool = false
}
